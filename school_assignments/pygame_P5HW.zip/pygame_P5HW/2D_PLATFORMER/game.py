import pygame
import sys
import random

# 👾 Jazmine Legall
# 11/24/2024 (Updated)
# P5HW
# Create a mini pygame Python Game. Using PygameYouTube channels given before as well as AI chat to check work.
# Coding with Russ | ClearCode | DaFluffyPotato | ProgrammingKnowledge

# GAME CONSTANTS
HEALTH_MAX = 100
MANA_MAX = 100
HEAL_COST = 15
HEAL_AMOUNT = 20
ABSORB_HEALTH_COST = 25
ABSORB_ATTACK_GAIN = 35

# PLAYER ATTACK RANGES
BASIC_ATTACK_MIN = 20
BASIC_ATTACK_MAX = 40
CORRUPTION_ATTACK_MIN = 25
CORRUPTION_ATTACK_MAX = 65

pygame.init() # init means to initiate 

# DISPLAY SETTINGS
screen_height = 640
screen_width = 940
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('project ALPHA') # Window title

# COLORS
white = (255, 255, 255)
black = (0, 0, 0)
gray = (150, 150, 150)
blood = (255, 0, 0)

# LOAD FONTS
try:
    joystix_font = pygame.font.Font('assets/fonts/joystix monospace.otf', 20)
    minecraft_font = pygame.font.Font('assets/fonts/Minecraft.ttf', 14)
except:
    joystix_font = pygame.font.SysFont(None, 20)
    minecraft_font = pygame.font.SysFont(None, 14)

# LOAD IMAGES
logo = pygame.image.load('assets/graphics/title.png')
logo_rect = logo.get_rect(center=(screen_width // 2, 100))
title = pygame.image.load('assets/graphics/title_b.png')
title_rect = title.get_rect(center=(screen_width // 2, 150))
goddess = pygame.image.load('assets/graphics/goddess.png')
corruption_img = pygame.image.load('assets/graphics/corruption.png')
avatars = [pygame.image.load(f'assets/graphics/avatar{i}.png') for i in range(1, 4)]
avatars = [pygame.transform.scale(avatar, (100, 100)) for avatar in avatars]

# CORRUPTION IMAGE
corruption_img = pygame.transform.scale(corruption_img, (290, 300))

# GAME STATES
STATE_MENU = 'menu'
STATE_CREATE_CHARACTER = 'create_character'
STATE_BATTLE = 'battle'
STATE_ABSORB_WARNING = 'absorb_warning'

class Character:
  
    def __init__(self, name, is_corruption=False):
        self.name = name
        self.health = HEALTH_MAX
        self.mana = MANA_MAX
        self.base_attack = random.randint(15, 35)  # Initial attack range
        self.has_absorbed = False
        self.is_corruption = is_corruption
        self.status_effects = []  # List to track status effects and cooldowns

    def get_attack_damage(self):
     
        if self.is_corruption:
            return random.randint(CORRUPTION_ATTACK_MIN, CORRUPTION_ATTACK_MAX)
        elif self.has_absorbed:
            # Absorbed attacks have higher minimum damage
            min_damage = self.base_attack + 20
            max_damage = self.base_attack + 45
            return random.randint(min_damage, max_damage)
        else:
            # Normal attacks have random damage within base range
            return random.randint(BASIC_ATTACK_MIN, BASIC_ATTACK_MAX)

    def add_status_effect(self, effect, duration):
        self.status_effects.append({"effect": effect, "duration": duration})

    def update_status_effects(self):
        self.status_effects = [
            status for status in self.status_effects
            if status["duration"] > 0
        ]
        for status in self.status_effects:
            status["duration"] -= 1

class Game:
    def __init__(self):
        self.state = STATE_MENU
        self.menu_options = ['Start Game', 'Create Character', 'Quit']
        self.selected_option = 0
        self.character = None
        self.corruption = Character("Corruption", True)
        self.selected_avatar = 0
        self.character_name = ''
        self.show_absorb_warning = True
        self.battle_log = []
        self.player_turn = True
        self.game_over = False

    def create_character_screen(self):
        screen.fill(black)
        
        # DISPLAY GODDESS IMAGE
        goddess_scaled = pygame.transform.scale(goddess, (600, 250))
        goddess_rect = goddess_scaled.get_rect(center=(screen_width // 2, 130))
        screen.blit(goddess_scaled, goddess_rect)
        
        # SELECT AVATAR TEXT
        text = joystix_font.render('SELECT YOUR AVATAR...', True, white)
        screen.blit(text, (screen_width // 2 - text.get_width() // 2, 250))
        
        # AVATAR SELECTION
        for i, avatar in enumerate(avatars):
            x = screen_width // 2 - 220 + i * 150
            y = 300
            border_color = white if i == self.selected_avatar else gray
            pygame.draw.rect(screen, border_color, (x - 5, y - 5, 110, 110), 2)
            screen.blit(avatar, (x, y))
        
        # NAME INPUT
        name_text = joystix_font.render(f'NAME: {self.character_name}_', True, white)
        screen.blit(name_text, (screen_width // 2 - name_text.get_width() // 2, 450))

    def perform_absorb(self):

        self.character.health -= ABSORB_HEALTH_COST
        self.character.base_attack += ABSORB_ATTACK_GAIN
        self.character.has_absorbed = True
        self.battle_log.append(f"{self.character.name} absorbed corruption power!")
        
        # Apply immediate attack with randomized damage
        damage = self.character.get_attack_damage()
        self.corruption.health -= damage
        self.battle_log.append(f"{self.character.name} attacks with corrupted power for {damage} damage!")
         
        self.state = STATE_BATTLE
        if not self.check_game_over():
            self.player_turn = False
            self.corruption_turn()
            self.check_game_over()

    def handle_battle_action(self, action):
       
        try:
            if action == '1':  # Attack
                damage = self.character.get_attack_damage()
                self.corruption.health -= damage
                self.character.mana = min(MANA_MAX, self.character.mana + 5)
                self.battle_log.append(f"{self.character.name} attacks for {damage} damage!")
                self.player_turn = False
                
            elif action == '2' and not self.character.has_absorbed:  # Heal
                if self.character.mana >= HEAL_COST:
                    self.character.mana -= HEAL_COST
                    heal_amount = HEAL_AMOUNT
                    self.character.health = min(HEALTH_MAX, self.character.health + heal_amount)
                    self.battle_log.append(f"{self.character.name} heals for {heal_amount} HP!")
                    self.player_turn = False
                    
            elif action == '3' and not self.character.has_absorbed:  # Absorb
                if self.show_absorb_warning:
                    self.state = STATE_ABSORB_WARNING
                else:
                    self.perform_absorb()
                    self.player_turn = False
                    
        except Exception as e:
            self.battle_log.append(f"Error processing action: {str(e)}")

    def battle_screen(self):
        screen.fill(black)
        
        # DRAW CHARACTERS AVATARS
        player_avatar = avatars[self.selected_avatar]
        player_pos = (170, screen_height // 2 - 150)
        corruption_pos = (screen_width - 380, screen_height // 2 - 250)
        
        screen.blit(player_avatar, player_pos)
        screen.blit(corruption_img, corruption_pos)
        
        # CHARACTER STATS 
        player_stats_y = 460
        corruption_stats_y = 460
        
        # HEALTH BARS ❤️
        player_health = pygame.Rect(50, player_stats_y, 200 * (self.character.health / 100), 15)
        corruption_health = pygame.Rect(screen_width - 300, corruption_stats_y, 250 * (self.corruption.health / 100), 15)
        
        pygame.draw.rect(screen, white, (50, player_stats_y, 200, 15), 1)
        pygame.draw.rect(screen, white, (screen_width - 300, corruption_stats_y, 250, 15), 1)
        pygame.draw.rect(screen, white, player_health)
        pygame.draw.rect(screen, white, corruption_health)
        
        # MANA BARS 🪄
        player_mana = pygame.Rect(50, player_stats_y + 30, 200 * (self.character.mana / 100), 15)
        corruption_mana = pygame.Rect(screen_width - 300, corruption_stats_y + 30, 150 * (self.corruption.mana / 100), 15)
        
        pygame.draw.rect(screen, white, (50, player_stats_y + 30, 200, 15), 1)
        pygame.draw.rect(screen, white, (screen_width - 250, corruption_stats_y + 30, 200, 15), 1)
        pygame.draw.rect(screen, white, player_mana)
        pygame.draw.rect(screen, white, corruption_mana)
        
        # STATS TEXT
        player_stats = [
            f"{self.character.name}",
            f"Health: {self.character.health}",
            f"Mana: {self.character.mana}",
            f"Attack: {self.character.base_attack}"
        ]
        
        corruption_stats = [
            "Corruption",
            f"Health: {self.corruption.health}",
            f"Mana: {self.corruption.mana}",
            f"Attack: {self.corruption.base_attack}"
        ]
        
        for i, stat in enumerate(player_stats):
            text = minecraft_font.render(stat, True, white)
            screen.blit(text, (50, player_stats_y + 60 + i * 20))
            
        for i, stat in enumerate(corruption_stats):
            text = minecraft_font.render(stat, True, white)
            screen.blit(text, (screen_width - 300, corruption_stats_y + 60 + i * 20))
        
        # BATTLE OPTIONS
        if self.player_turn:
            options = [
                "1: Attack (Restore 5 Mana)",
                "2: Heal (-15 Mana)" if not self.character.has_absorbed else "",
                "3: Absorb (-25 Health, +35 Attack)" if not self.character.has_absorbed else ""
            ]
            
            for i, option in enumerate(options):
                if option:
                    text = minecraft_font.render(option, True, white)
                    screen.blit(text, (screen_width // 2 - text.get_width() // 2, screen_height - 150 + i * 30))
        
        # BATTLE LOG
        for i, log in enumerate(self.battle_log[-5:]):
            text = minecraft_font.render(log, True, white)
            screen.blit(text, (50, screen_height - 300 + i * 20))

    def corruption_turn(self):
        if self.corruption.mana >= 25 and random.random() < 0.3:
            stolen_mana = min(45, self.character.mana)
            self.character.mana -= stolen_mana
            self.corruption.mana += stolen_mana
            self.battle_log.append(f"Corruption steals {stolen_mana} mana!")
        else:
            damage = self.corruption.get_attack_damage()
            self.character.health -= damage
            self.battle_log.append(f"Corruption attacks for {damage} damage!")
        
        self.player_turn = True

    def absorb_warning_screen(self):
        overlay = pygame.Surface((screen_width, screen_height))
        overlay.fill(black)
        overlay.set_alpha(200)
        screen.blit(overlay, (0, 0))
        
        warning_text = [
            "Beware, mortal...",
            "When you wield the power to absorb the darkness of corruption.",
            "It may grant you strength beyond measure, yet know this-such power demands a toll.",
            "Your very blood shall be its price.",
            "",
            "Press ENTER to continue",
            "Press ESC to cancel"
        ]
        
        y = screen_height // 2 - len(warning_text) * 20
        for text in warning_text:
            rendered_text = minecraft_font.render(text, True, blood if "absorb" in text else white)
            text_rect = rendered_text.get_rect(center=(screen_width // 2, y))
            screen.blit(rendered_text, text_rect)
            y += 50

    def check_game_over(self):
        if self.character.health <= 0:
            self.battle_log.append("Game Over - Corruption wins!")
            self.battle_log.append("Press ENTER to return to menu")
            self.game_over = True
            return True
        elif self.corruption.health <= 0:
            self.battle_log.append(f"Game Over - {self.character.name} wins!")
            self.battle_log.append("Press ENTER to return to menu")
            self.game_over = True
            return True
        return False

    def reset_game(self):
        # RESET GAME
        self.state = STATE_MENU
        self.corruption = Character("Corruption", True)
        self.game_over = False
        self.show_absorb_warning = True
        self.battle_log = []
        self.player_turn = True


def main():
    game = Game()
    clock = pygame.time.Clock()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                
            if event.type == pygame.KEYDOWN:
                if game.game_over and event.key == pygame.K_RETURN:
                    game = Game()  # Create a completely new game instance
                    continue
                        
                # Handle absorb warning state            
                elif game.state == STATE_ABSORB_WARNING:
                    if event.key == pygame.K_RETURN:
                        game.show_absorb_warning = False
                        game.state = STATE_BATTLE
                        game.perform_absorb()
                    elif event.key == pygame.K_ESCAPE:
                        game.state = STATE_BATTLE        
                
                # Handle battle state
                elif game.state == STATE_BATTLE and not game.game_over:
                    if game.player_turn:
                        if event.key in [pygame.K_1, pygame.K_2, pygame.K_3]:
                            game.handle_battle_action(event.unicode)
                            
                            if not game.check_game_over() and not game.player_turn:
                                game.corruption_turn()
                                game.check_game_over()

                

                elif game.state == STATE_MENU:
                    if event.key == pygame.K_UP:
                        game.selected_option = (game.selected_option - 1) % len(game.menu_options)
                        
                    elif event.key == pygame.K_DOWN:
                        game.selected_option = (game.selected_option + 1) % len(game.menu_options)
                    elif event.key == pygame.K_RETURN:
                        if game.menu_options[game.selected_option] == 'Start Game' and game.character:
                            game.state = STATE_BATTLE
                            game.player_turn = True
                            game.battle_log = []
                            game.game_over = False
                        elif game.menu_options[game.selected_option] == 'Create Character':
                            game.state = STATE_CREATE_CHARACTER
                            game.character_name = ''
                        elif game.menu_options[game.selected_option] == 'Quit':
                            pygame.quit()
                            sys.exit()
                            
                elif game.state == STATE_CREATE_CHARACTER:
                    if event.key == pygame.K_RETURN and game.character_name:
                        game.character = Character(game.character_name)
                        game.state = STATE_MENU
                    elif event.key == pygame.K_BACKSPACE:
                        game.character_name = game.character_name[:-1]
                    elif event.key == pygame.K_LEFT:
                        game.selected_avatar = (game.selected_avatar - 1) % len(avatars)
                    elif event.key == pygame.K_RIGHT:
                        game.selected_avatar = (game.selected_avatar + 1) % len(avatars)
                    elif len(game.character_name) < 10 and event.unicode.isalnum():
                        game.character_name += event.unicode                

        # RENDER CURRENT STATE
        if game.state == STATE_MENU:
            screen.fill(black)
            screen.blit(logo, logo_rect)
            for i, option in enumerate(game.menu_options):
                color = blood if i == game.selected_option else white
                text = joystix_font.render(option, True, color)
                text_rect = text.get_rect(center=(screen_width // 2, 250 + i * 50))
                screen.blit(text, text_rect)
                
        elif game.state == STATE_CREATE_CHARACTER:
            game.create_character_screen()
            
        elif game.state == STATE_BATTLE:
            game.battle_screen()

            if game.game_over:
                game_over_text = joystix_font.render("Game Over!", True, blood)
                text_rect = game_over_text.get_rect(center=(screen_width // 2, screen_height - 100))
                screen.blit(game_over_text, text_rect)
                
                enter_text = joystix_font.render("Press ENTER to return to menu", True, blood)
                enter_rect = enter_text.get_rect(center=(screen_width // 2, screen_height - 50))
                screen.blit(enter_text, enter_rect)
            
        elif game.state == STATE_ABSORB_WARNING:
            game.battle_screen()  # Draw battle screen in background
            game.absorb_warning_screen()
        
        pygame.display.flip()
        clock.tick(60)

if __name__ == '__main__':
    main()